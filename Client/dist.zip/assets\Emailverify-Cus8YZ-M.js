import{j as r}from"./vendor-ui-BXGGahtn.js";import"./vendor-react-DH9UJIRf.js";const e=()=>r.jsx("div",{children:"Emailverify"});export{e as default};
